### Hi there, I'm [Karthik Mothiki](https://karthikmothiki.github.io/Portfolio/) aka Karthik👋
- B.Tech Mechatronics Engineering. As a Student of Mechatronics Engineering, My Field of Interest is very diverse. I am Familiar with Python, JAVA, C, C++, Kotlin. I Enjoy Coding, majorly have passion towards Robotics and Learning new Technologies. My dream is to become a Skilled Robotics Engineer.:smile::smile:

### Experience!:briefcase:
  - Technical Content Writer (Internship)
    - AI Tech Web
      - May 2020 - July 2020

  - Campus Ambassador (Internship)
    - Indian Robotics Community
      - September 2020 - Present

### Education!
  - Sastra Deemed University:mortar_board::
    - Bachelor's Degree, Mechatronics Engineering
      - 2019 - 2023
  - Sarada Educational Instituitions:school_satchel::
    - High School 
      - 2017 - 2019
  - Viswavani E.M High School:school::
     - 2016 - 2017

### Licenses & Certifications
  - Python For Everybody Specialization
    - Coursera - Aug 2020
      - [Credential ID GFSU9RBCV5DF](https://www.coursera.org/account/accomplishments/specialization/certificate/GFSU9RBCV5DF)
  - AWS Technical Essentials and Architecting
    - Coursera - June 2020
      - [Credential ID DU2PYK9I](https://drive.google.com/file/d/183oGrley9EHkHigEoo6Tsx6V6_CBJU9Y/view)
  - AI For Everyone
    - Coursera - July 2020
      - [Credential ID FNY5HEHTRGMN](https://www.coursera.org/account/accomplishments/certificate/FNY5HEHTRGMN)
  - Introduction to Virtual Reality
    - Coursera - Aug 2020
      - [Credential ID HB4K9CH2LD3U](https://www.coursera.org/account/accomplishments/certificate/HB4K9CH2LD3U)      

  
### Languages and Tools:

<img align="left" alt="Git" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png" />
<img align="left" alt="GitHub" width="26px" src="https://raw.githubusercontent.com/github/explore/78df643247d429f6cc873026c0622819ad797942/topics/github/github.png" />
<img align="left" alt="Linux" width="26px" src="https://raw.githubusercontent.com/github/explore/master/topics/linux/linux.png" />
<img align="left" alt="Python" width="26px" src="https://raw.githubusercontent.com/github/explore/master/topics/python/python.png" />
<img align="left" alt="Android" width="26px" src="https://raw.githubusercontent.com/github/explore/master/topics/android/android.png" />
<img align="left" alt="Visual Studio Code" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/visual-studio-code/visual-studio-code.png" />
<img align="left" alt="Sublime Text" width="26px" src="https://raw.githubusercontent.com/github/explore/master/topics/sublime-text/sublime-text.png" />

<br />
<br />

### Connect with me:

[<img align="left" alt="KarthikMothiki | LinkedIn" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.3.0/icons/linkedin.svg" />][linkedin]
[<img align="left" alt="KarthikMothiki | Whatsapp" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.3.0/icons/whatsapp.svg" />][whatsapp]
[<img align="left" alt="KarthikMothiki | Telegram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.3.0/icons/telegram.svg" />][telegram]
[<img align="left" alt="KarthikMothiki | Messenger" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.3.0/icons/messenger.svg" />][messenger]
[<img align="left" alt="KarthikMothiki | Facebook" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.3.0/icons/facebook.svg" />][facebook]
[<img align="left" alt="KarthikMothiki | Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />][instagram]
[<img align="left" alt="KarthikMothiki | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />][twitter]


<br />
<br />



[linkedin]: https://www.linkedin.com/in/karthikmothiki/
[whatsapp]: https://api.whatsapp.com/send/?phone=%2B919441315721&text&app_absent=0
[telegram]: https://t.me/Karthik_Mothiki
[messenger]: https://m.me/karthik.mothiki
[facebook]: https://www.facebook.com/karthik.mothiki/
[instagram]: https://www.instagram.com/karthik_mothiki/
[twitter]: https://twitter.com/KarthikMothiki
![Github stats](https://github-readme-stats.vercel.app/api?username=KarthikMothiki)

